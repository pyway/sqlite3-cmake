
#!/bin/sh

CROSS_COMPILE=/home/workspace/program-files/arago-2017.06/sysroots/x86_64-arago-linux/usr/bin/arm-linux-gnueabihf
export CC=$CROSS_COMPILE-gcc
#CC=arm-linux-gnueabihf-
./configure --prefix=/home/workspace/rootfs/usr --host=/home/workspace/program-files/arago-2017.06/sysroots/x86_64-arago-linux/usr/bin/arm-linux-gnueabihf

make && make install

